#include <stdio.h>
#include <stdlib.h>

#include "../ADT/mesinkata.h"
#include "../ADT/array.h"

#ifndef LOAD_H
#define LOAD_H

void LOAD();

#endif