#include <stdio.h>
#include <stdlib.h>

#include "../ADT/mesinkata.h"
#include "../ADT/array.h"

#ifndef START_H
#define START_H

void STARTGAME();

#endif