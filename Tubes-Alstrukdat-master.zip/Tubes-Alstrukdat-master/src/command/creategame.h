#ifndef __CREATEGAME__
#define __CREATEGAME__

#include "../ADT/array.h"

/*
Menambahkan game baru pada daftar game
*/
void CREATEGAME(Arr *arrgame);

#endif
