#include "../boolean.h"

#ifndef QUIT_H
#define QUIT_H

void quit(boolean *isQuit);

#endif