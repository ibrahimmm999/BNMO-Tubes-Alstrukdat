#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "../boolean.h"
#include "../ADT/mesinkata.h"

#ifndef RNG_H
#define RNG_H

void RNG();

#endif