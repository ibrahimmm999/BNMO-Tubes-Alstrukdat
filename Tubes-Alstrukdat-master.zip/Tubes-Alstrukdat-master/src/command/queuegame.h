#include <stdio.h>

#include "../ADT/queueV2.h"
#include "../ADT/mesinkata.h"
#include "../ADT/array.h"

void QUEUEGAME(Queue *queueGame, Arr arrGame);