#ifndef __BOOLEAN_h__
#define __BOOLEAN_h__

#define boolean unsigned char
#define true 1
#define false 0

#endif