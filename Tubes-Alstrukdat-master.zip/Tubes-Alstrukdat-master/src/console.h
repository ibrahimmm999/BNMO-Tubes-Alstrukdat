#include "adt.h"
#ifndef CONSOLE_H
#define CONSOLE_H

void DISPLAYBANNER();
void MAINMENU();

#endif
