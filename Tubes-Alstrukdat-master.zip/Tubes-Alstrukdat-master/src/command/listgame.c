#include "listgame.h"
#include <stdio.h>

void LISTGAME(Arr arrgame){
    printf("Berikut adalah daftar game yang tersedia\n");

    TulisIsi(arrgame);
}
