#include "../ADT/array.h"

#ifndef SAVE_H
#define SAVE_H

void save(char *file_name, Arr list_game);

#endif