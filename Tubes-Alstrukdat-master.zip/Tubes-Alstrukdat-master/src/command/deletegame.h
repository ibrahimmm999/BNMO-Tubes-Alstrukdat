#ifndef __DELETEGAME__
#define __DELETEGAME__

#include "../ADT/array.h"
#include "../ADT/queueV2.h"

/*
Menghapus sebuah game dari daftar game
*/
void DELETEGAME(Arr *arrgame, Queue queueGame);

#endif