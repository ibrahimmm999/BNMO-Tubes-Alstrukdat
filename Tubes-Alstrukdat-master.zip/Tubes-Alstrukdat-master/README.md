IF2111 Algoritma dan Struktur Data
Tugas Besar 1 

Dibuat oleh kelompok 7 K02 dengan anggota:
1. Gevyndo Gunawan            (18221076)
2. Imam Rusydi Ibrahim        (18221140)
3. Yasmin Arum Sari           (18221142)
4. Tara Chandani Haryono      (18221146)
5. Angela Geraldine Hasian P. (18221158)

Tugas besar ini memiliki misi utama memprogram ulang BNOMO--sebuah video game console. Program yang dibuat dalam bahasa
C menggunakan library stdio.h, stdlib.h, mat.h, dan time.h dengan bantuan ADT array, mesin karakter dan mesin kata, serta
queue ini memiliki 4 fitur utama berupa memainkan, menambahkan, dan menghapus game, serta mengurutkan game yang akan
dimainkan. Terdapat beberapa command pendukung fitur-fitur tersebut, meliputi START, LOAD, SAVE, CREATEGAME, LISTGAME,
DELETEGAME, QUEUEGAME, PLAYGAME, SKIPGAME, dan QUIT. Kegunaan setiap command dapat dilihat dengan mengakses command HELP.

Program akan dimulai dengan menampilkan main menu berisi ///insert isi tampilan main menu///. Pengguna akan diarahkan untuk
memulai permainan dengan mengetikkan command yang sesuai. Saat memulai permainan, akan dibaca sebuah file konfigurasi
berisi jumlah permainan dan nama-nama permainan tersebut. Sejauh ini, program ini memiliki 2 permainan default, yaitu
RNG (permainan menebak angka) dan Diner Dash (permainan menyajikan makanan cepat saji).

Berikut cara kompilasi program.
///insert cara kompilasi program///




