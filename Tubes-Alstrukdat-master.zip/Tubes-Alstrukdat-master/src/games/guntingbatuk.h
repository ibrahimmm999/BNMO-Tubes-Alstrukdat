#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "../ADT/mesinkata.h"
#include "../ADT/list.h"
#include "../boolean.h"

#ifndef TICTACTOE_H
#define TICTACTOE_H

void gbk();

#endif