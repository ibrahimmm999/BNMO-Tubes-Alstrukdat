/* file: converter.h */

#ifndef _CONVERTER_H_
#define _CONVERTER_H_

#define m 'M'

#include "mesinkata.h"

char nConversion(int n);

void convert(Word *w, int n);

#endif