#ifndef __LISTGAME__
#define __LISTGAME__

#include "../ADT/array.h"

/*
Menampilkan daftar game yang disediakan oleh sistem
*/
void LISTGAME();
#endif
