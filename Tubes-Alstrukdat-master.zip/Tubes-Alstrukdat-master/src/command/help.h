#include <stdio.h>

void DISPLAYHELP();